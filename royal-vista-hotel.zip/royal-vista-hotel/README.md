# Royal Vista Hotel Website

A responsive static hotel website built with HTML, CSS, and vanilla JavaScript.

## Files
- `index.html` — page structure and content
- `style.css` — layout, styling, and responsive breakpoints
- `script.js` — mobile navigation, room preselection, date validation, and demo form feedback

## Run locally
Open `index.html` in a browser. An internet connection is needed for the Google Fonts and remote Unsplash images.

## Publish with GitHub Pages
1. Create a public GitHub repository named `royal-vista-hotel`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/(root)`, then save.
5. Wait for the Pages deployment and open the URL shown in Settings → Pages.

## Before using for a real hotel
- Replace the sample hotel name, address, telephone number, email, and room descriptions.
- Verify image usage and replace remote images with approved hotel photography if needed.
- The enquiry form is front-end only. It does not send, save, or confirm a booking. Connect a secure backend or a trusted form/booking service for real enquiries, and add appropriate privacy information before collecting customer data.
