const menuToggle = document.querySelector(".menu-toggle");
const mainNav = document.querySelector(".main-nav");
const bookingForm = document.querySelector("#booking-form");
const checkInInput = document.querySelector("#check-in");
const checkOutInput = document.querySelector("#check-out");
const roomTypeSelect = document.querySelector("#room-type");
const formMessage = document.querySelector("#form-message");

// Return today's date in YYYY-MM-DD format using the visitor's local date.
function getLocalDateString(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

const today = getLocalDateString();
checkInInput.min = today;
checkOutInput.min = today;

// Open and close the mobile navigation menu.
menuToggle.addEventListener("click", () => {
  const isOpen = mainNav.classList.toggle("is-open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
});

// Close the mobile menu after a navigation link is selected.
mainNav.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("is-open");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.setAttribute("aria-label", "Open navigation");
  });
});

// Room-card links preselect the room in the enquiry form.
document.querySelectorAll("[data-room]").forEach((link) => {
  link.addEventListener("click", () => {
    roomTypeSelect.value = link.dataset.room;
  });
});

// The checkout date must be later than the check-in date.
checkInInput.addEventListener("change", () => {
  const earliestCheckout = checkInInput.value || today;
  checkOutInput.min = earliestCheckout;

  if (checkOutInput.value && checkOutInput.value <= checkInInput.value) {
    checkOutInput.value = "";
  }
});

// Demonstration-only form handling. No booking is sent or stored.
bookingForm.addEventListener("submit", (event) => {
  event.preventDefault();

  if (!checkInInput.value || !checkOutInput.value || checkOutInput.value <= checkInInput.value) {
    formMessage.textContent = "Please choose a check-out date after your check-in date.";
    return;
  }

  const formData = new FormData(bookingForm);
  const guestName = String(formData.get("fullName")).trim();
  const roomType = formData.get("roomType");
  const checkIn = formData.get("checkIn");
  const checkOut = formData.get("checkOut");

  formMessage.textContent = `Thank you, ${guestName}. Your ${roomType} enquiry for ${checkIn} to ${checkOut} is ready. This demo has not sent a reservation.`;
});

// Keep the copyright year current.
document.querySelector("#year").textContent = new Date().getFullYear();
